from django.apps import AppConfig


class ApplicantprofileConfig(AppConfig):
    name = 'applicantprofile'
