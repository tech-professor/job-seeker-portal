This project is no longer maintained.<br/>
===========================

**Employee Recruitment System**<br/>

**Introduction**<br/>
This repository consists of a simple recruitment system developed using PHP and MySQL which facilites oraganization to post their staffing requirements and view profiles of interested candidates. Also, organization can sort interested candidates and schedule their exams and interviews. It can be helpful for candidates to find requirements in the company and to apply for appropriate job. The primary purpose to develop this system is to optimize the recruitment process for an organization.


**Usage**<br/>
Using <a href="https://www.apachefriends.org/index.html">XAMPP</a> or <a href="http://www.wampserver.com/en/">WMPP</a> :
- Copy extracted files to the web server's root directory [most probably, `C:\xampp\htdocs` in XAMPP or `C:\wamp\www` in WAMP].
- Start APACHE and MySQL servers from XAMPP/WAMP control panel.
- Go to phpmyadmin from XAMPP/WAMP control panel and create a blank database named 'recruitment'.
- Import `recruitment.sql` to this database.
- Change the host, user, password in `connect.php` according to your phpmyadmin credentials.
- Finally, access the project files throgh url `localhost/<local_dirctory_path>` in your browser.

**Screenshots**<br/>
<a href = "/../master/others/screenshots/">All screenshots are here</a><br/><br/>







 
