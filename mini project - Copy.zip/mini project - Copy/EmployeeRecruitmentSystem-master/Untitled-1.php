<html>
<head>
<title>Feedback</title>
 </head>
<body>
<?
if(isset($submit)){
    $to = "webmaster@domain.com"; // Enter YOUR email here
  $subject = "Feedback for the Website!";
 $body = "A user has entered feedback on the site!\n";
 $body .= "Their feedback is:\n\n";
 $body .= $feedback;
 mail($to, $subject, $body);
  print("<h2>Thanks for your feedback!</h2>");
 } else {
?>
<form action="feedback.php" method="POST">
<h2>Please Send us your Feedback</h2>
<textarea cols=35 rows=15 name="feedback">
</textarea>
 <br>
 <input type="submit" name="submit" value="Submit">
</form>
<?
}
?>
</body>
</html>